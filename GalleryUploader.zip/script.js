document.addEventListener('DOMContentLoaded', () => {
    const uploadForm = document.getElementById('uploadForm');
    const imageInput = document.getElementById('imageInput');
    const preview = document.getElementById('preview');
    const previewImage = document.getElementById('previewImage');
    const gallery = document.getElementById('gallery');
    const themeToggle = document.getElementById('themeToggle');

    // تنظیم تم اولیه
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.classList.toggle('dark', savedTheme === 'dark');

    // تغییر تم
    themeToggle.addEventListener('click', () => {
        const isDark = document.documentElement.classList.toggle('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });

    // پیش‌نمایش تصویر قبل از آپلود
    imageInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                previewImage.src = e.target.result;
                preview.classList.remove('hidden');
                preview.classList.add('animate-fade-in');
            };
            reader.readAsDataURL(file);
        }
    });

    // آپلود تصویر
    uploadForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('image', imageInput.files[0]);

        try {
            const response = await fetch('upload.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();
            if (result.success) {
                // اضافه کردن تصویر جدید به گالری
                addImageToGallery(result.imageUrl);
                // پاک کردن فرم
                uploadForm.reset();
                preview.classList.add('hidden');
                previewImage.src = '';
            } else {
                alert('خطا در آپلود تصویر: ' + result.message);
            }
        } catch (error) {
            alert('خطا در ارتباط با سرور');
        }
    });

    // نمایش تصاویر موجود در گالری
    loadGallery();

    // تابع اضافه کردن تصویر به گالری
    function addImageToGallery(imageUrl) {
        const div = document.createElement('div');
        div.className = 'relative group animate-fade-in';
        div.innerHTML = `
            <img src="${imageUrl}" alt="تصویر آپلود شده" class="w-full h-48 object-cover rounded-lg shadow-md">
            <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                <button onclick="deleteImage('${imageUrl}')" class="text-white hover:text-red-500 transition-colors">
                    <i class="fas fa-trash-alt text-xl"></i>
                </button>
            </div>
        `;
        gallery.insertBefore(div, gallery.firstChild);
    }

    // تابع بارگذاری گالری
    async function loadGallery() {
        try {
            const response = await fetch('get_images.php');
            const images = await response.json();
            images.forEach(imageUrl => addImageToGallery(imageUrl));
        } catch (error) {
            console.error('خطا در بارگذاری گالری:', error);
        }
    }
});

// تابع حذف تصویر
async function deleteImage(imageUrl) {
    if (confirm('آیا از حذف این تصویر اطمینان دارید؟')) {
        try {
            const response = await fetch('delete_image.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ imageUrl })
            });

            const result = await response.json();
            if (result.success) {
                // حذف تصویر از گالری
                const imageElement = document.querySelector(`img[src="${imageUrl}"]`).parentElement;
                imageElement.remove();
            } else {
                alert('خطا در حذف تصویر: ' + result.message);
            }
        } catch (error) {
            alert('خطا در ارتباط با سرور');
        }
    }
} 