<!DOCTYPE html>
<html lang="fa" dir="rtl" class="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سیستم آپلود تصویر</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fadeIn 0.5s ease-out;
        }
        .dark body {
            background-color: #1a1a1a;
            color: #ffffff;
        }
        .dark .bg-white {
            background-color: #2d2d2d;
        }
        .dark .text-gray-800 {
            color: #ffffff;
        }
        .dark .text-gray-600 {
            color: #d1d1d1;
        }
        .dark .border-gray-300 {
            border-color: #4a4a4a;
        }
        .dark .hover\:border-blue-500:hover {
            border-color: #3b82f6;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen transition-colors duration-200">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-6 animate-fade-in">
            <div class="flex justify-between items-center mb-8">
                <h1 class="text-3xl font-bold text-gray-800">
                    <i class="fas fa-cloud-upload-alt text-blue-500 mr-2"></i>
                    آپلود تصویر
                </h1>
                <button id="themeToggle" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                    <i class="fas fa-sun text-yellow-500 dark:hidden"></i>
                    <i class="fas fa-moon text-blue-300 hidden dark:block"></i>
                </button>
            </div>
            
            <div class="mb-8">
                <form id="uploadForm" class="space-y-4" enctype="multipart/form-data">
                    <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
                        <input type="file" id="imageInput" accept="image/*" class="hidden">
                        <label for="imageInput" class="cursor-pointer">
                            <i class="fas fa-image text-4xl text-gray-400 mb-2"></i>
                            <p class="text-gray-600">برای آپلود تصویر کلیک کنید یا آن را اینجا رها کنید</p>
                        </label>
                    </div>
                    <div id="preview" class="hidden mt-4">
                        <img id="previewImage" class="max-w-full h-auto rounded-lg shadow-md" src="" alt="پیش‌نمایش">
                    </div>
                    <button type="submit" class="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors">
                        <i class="fas fa-upload mr-2"></i>
                        آپلود تصویر
                    </button>
                </form>
            </div>

            <div id="gallery" class="grid grid-cols-2 md:grid-cols-3 gap-4">
                <!-- تصاویر آپلود شده اینجا نمایش داده می‌شوند -->
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html> 