<?php
header('Content-Type: application/json');

$uploadDir = 'uploads/';
$images = [];

if (file_exists($uploadDir)) {
    $files = scandir($uploadDir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..') {
            $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                $images[] = $uploadDir . $file;
            }
        }
    }
}

echo json_encode($images); 