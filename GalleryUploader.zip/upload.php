<?php
header('Content-Type: application/json');

// تنظیمات آپلود
$uploadDir = 'uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// بررسی وجود فایل
if (!isset($_FILES['image'])) {
    echo json_encode(['success' => false, 'message' => 'هیچ فایلی ارسال نشده است']);
    exit;
}

$file = $_FILES['image'];

// بررسی خطاهای آپلود
if ($file['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'خطا در آپلود فایل']);
    exit;
}

// بررسی نوع فایل
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
if (!in_array($file['type'], $allowedTypes)) {
    echo json_encode(['success' => false, 'message' => 'فرمت فایل مجاز نیست']);
    exit;
}

// ایجاد نام یکتا برای فایل
$extension = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = uniqid() . '.' . $extension;
$targetPath = $uploadDir . $filename;

// آپلود فایل
if (move_uploaded_file($file['tmp_name'], $targetPath)) {
    echo json_encode([
        'success' => true,
        'imageUrl' => $targetPath
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'خطا در ذخیره فایل']);
} 