<?php
header('Content-Type: application/json');

// دریافت داده‌های ارسالی
$data = json_decode(file_get_contents('php://input'), true);
$imageUrl = $data['imageUrl'] ?? '';

if (empty($imageUrl)) {
    echo json_encode(['success' => false, 'message' => 'آدرس تصویر مشخص نشده است']);
    exit;
}

// بررسی امنیتی مسیر فایل
if (strpos($imageUrl, 'uploads/') !== 0) {
    echo json_encode(['success' => false, 'message' => 'مسیر فایل نامعتبر است']);
    exit;
}

// حذف فایل
if (file_exists($imageUrl) && unlink($imageUrl)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'خطا در حذف فایل']);
} 